#include <iostream>
#include <vector>
using namespace std;
int main() {
    vector<int> arr = {1, 2, 4, 5};
    arr.insert(arr.begin() + 2, 3); // Insert 3 at index 2
    for(int x : arr) cout << x << " ";
}
