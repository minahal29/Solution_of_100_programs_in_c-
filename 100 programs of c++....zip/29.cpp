#include <iostream>
using namespace std;

class Person {
public:
    Person(string name) { cout << "Hello, " << name << "!\n"; }
    ~Person() { cout << "Goodbye!\n"; }
};

int main() {
    Person p("Alice");
    return 0;
}
