#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int arr[] = {5, 2, 8, 1, 3}, n = 5;
    sort(arr, arr + n);
    for(int i = 0; i < n; i++) cout << arr[i] << " ";
}
