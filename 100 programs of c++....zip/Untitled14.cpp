#include <iostream>
using namespace std;

int main() {
    int n = 5;
    for (int i = 1; i <= n; i++) {
        for (int j = i; j < n; j++)
            cout << " ";
        for (char ch = 'A'; ch < 'A' + (2 * i - 1); ch++)
            cout << ch;
        cout << endl;
    }
    return 0;
}
