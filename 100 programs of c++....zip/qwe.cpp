#include<iostream>
using namespace std;
class CSM{
	public:
		CSM(int age,float height){
			cout<<"age is:"<<age<<","<<"height is:"<<height<<endl;
		}
};
int main(){
	CSM CS(18,5.1);
	return 0;
}