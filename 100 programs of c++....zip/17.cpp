#include <iostream>
using namespace std;
int main() {
    int a[] = {1, 3, 5}, b[] = {2, 4, 6}, c[6], i = 0, j = 0, k = 0;
    while(i < 3 && j < 3) c[k++] = (a[i] < b[j]) ? a[i++] : b[j++];
    while(i < 3) c[k++] = a[i++];
    while(j < 3) c[k++] = b[j++];
    for(int x : c) cout << x << " ";
}
