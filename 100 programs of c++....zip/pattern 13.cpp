#include<iostream>
using namespace std;
int main()
{
	int a=5;
	int x,y;
	for(int i=1;i<=a;i++)
	{
		x=i;
		y=a-i+1;
		for(int j=1;j<=a;j++)
		{
			if(j%2==1)
			{
				cout<<x<<" ";
			}
			else
			{
				cout<<y<<" ";
			}
			x=x+a;
			y=y+a;
		}
		cout<<endl;
	}
	return 0;
}