#include <iostream>
using namespace std;

class Student {
private:
    string *name;
public:
    Student(string n) { name = new string(n); }
    void display() { cout << "Student Name: " << *name << endl; }
    ~Student() { delete name; cout << "Memory freed\n"; }
};

int main() {
    Student s("John");
    s.display();
}
