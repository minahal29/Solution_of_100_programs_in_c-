#include <iostream>
using namespace std;

class Employee {
public:
    string name;
    double salary;

    void setData(string n, double s) {
        name = n;
        salary = s;
    }

    void displaySalary() {
        cout << "Employee: " << name << ", Salary: $" << salary << endl;
    }
};

int main() {
    Employee e;
    e.setData("John", 4500);
    e.displaySalary();
}
