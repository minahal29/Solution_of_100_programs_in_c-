#include <iostream>
using namespace std;

class Number {
public:
    int value;
    Number(int v) { value = v; }
    Number(const Number &n) { value = n.value; } // Copy Constructor
    void show() { cout << "Value: " << value << endl; }
};

int main() {
    Number num1(10);
    Number num2 = num1;
    num1.show();
    num2.show();
}
