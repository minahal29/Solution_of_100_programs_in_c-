#include <iostream>
using namespace std;
int main() {
    int arr[6] = {2, 3, 4, 5}, n = 4, val = 1;
    for(int i = n; i > 0; i--) arr[i] = arr[i-1];
    arr[0] = val; n++;
    for(int i = 0; i < n; i++) cout << arr[i] << " ";
}
