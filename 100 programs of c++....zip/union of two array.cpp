#include <iostream>
#include <set>
using namespace std;
int main() {
    int a[] = {1, 2, 3}, b[] = {2, 3, 4};
    set<int> s(a, a+3);
    for(int x : b) s.insert(x);
    for(int x : s) cout << x << " ";
}
