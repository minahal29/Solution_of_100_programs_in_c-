#include <iostream>
using namespace std;
int main() {
    int arr[6] = {1, 2, 3, 4, 5}, n = 5, val = 6;
    arr[n] = val; n++;
    for(int i = 0; i < n; i++) cout << arr[i] << " ";
}
