#include <iostream>
using namespace std;

int main() {
    int n = 5;
    for (int i = 1; i <= n; i++) {
        for (int j = i; j < n; j++)
            cout << " ";
        for (char ch = 'A'; ch < 'A' + i; ch++)
            cout << ch;
        for (char ch = 'A' + i - 2; ch >= 'A'; ch--)
            cout << ch;
        cout << endl;
    }
    for (int i = n - 1; i >= 1; i--) {
        for (int j = i; j < n; j++)
            cout << " ";
        for (char ch = 'A'; ch < 'A' + i; ch++)
            cout << ch;
        for (char ch = 'A' + i - 2; ch >= 'A'; ch--)
            cout << ch;
        cout << endl;
    }
    return 0;
}
