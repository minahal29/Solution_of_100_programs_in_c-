#include<iostream>
using namespace std;
int main()
{
	int a=5;
	int x;
	for(int i=1;i<=a;i++)
	{
		x=i;
		for(int j=1;j<=a;j++)
		{
			cout<<j<<" "<<i<<" ";
		}
		cout<<endl;
	}
	return 0;
}