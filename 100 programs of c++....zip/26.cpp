#include <iostream>
using namespace std;

class Student {
public:
    string name;
    int age;
    
    void inputDetails() {
        cout << "Enter name and age: ";
        cin >> name >> age;
    }

    void displayDetails() {
        cout << "Student Name: " << name << ", Age: " << age << endl;
    }
};

int main() {
    Student s1;
    s1.inputDetails();
    s1.displayDetails();
}
n