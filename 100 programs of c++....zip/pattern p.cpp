//pyramid pattern
      *
     ***
    *****
   *******
  *********


#include <iostream>
using namespace std;

int main() {
    int n = 5;
    for (int i = 1; i <= n; i++) {
        for (int j = i; j < n; j++)
            cout << " "; // Print spaces
        for (int j = 1; j <= (2 * i - 1); j++)
            cout << "*"; // Print stars
        cout << endl;
    }
    return 0;
}