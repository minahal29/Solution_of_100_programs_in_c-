#include <iostream>
using namespace std;
int main() {
    int arr[] = {1, 2, 3, 4, 5}, n = 5, temp = arr[n-1];
    for(int i = n-1; i > 0; i--) arr[i] = arr[i-1];
    arr[0] = temp;
    for(int x : arr) cout << x << " ";
}
