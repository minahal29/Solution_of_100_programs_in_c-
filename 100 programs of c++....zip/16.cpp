#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int arr[] = {7, 3, 9, 2, 5}, n = 5;
    sort(arr, arr + n);
    cout << "2nd Smallest: " << arr[1] << "\n2nd Largest: " << arr[n-2];
}
