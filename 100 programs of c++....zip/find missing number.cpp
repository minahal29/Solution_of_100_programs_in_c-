#include <iostream>
using namespace std;
int main() {
    int arr[] = {1, 2, 4, 5}, n = 5, sum = n*(n+1)/2;
    for(int x : arr) sum -= x;
    cout << "Missing Number: " << sum;
}
