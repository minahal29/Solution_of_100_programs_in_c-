#include <iostream>
using namespace std;
int main() {
    int arr[] = {2, 4, 6, 8}, n = 4, sum = 0;
    for(int x : arr) sum += x;
    cout << "Sum: " << sum << "\nAverage: " << (float)sum/n;
}
