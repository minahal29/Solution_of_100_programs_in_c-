#include <iostream>
using namespace std;

class Car {
public:
    Car() { cout << "Car created with default constructor\n"; }
    Car(string brand) { cout << "Car created: " << brand << endl; }
    ~Car() { cout << "Car object destroyed\n"; }
};

int main() {
    Car c1;
    Car c2("Toyota");
    return 0;
}
