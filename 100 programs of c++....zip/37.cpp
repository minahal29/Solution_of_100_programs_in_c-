#include<iostream>
using namespace std;
void insertionsort(int arr[],int n){
	
	for(int i=1;i<n;i++){
	int current = arr[i];
			int prev = i-1;
			
			while(prev >= 0 && arr[prev] < current){
				arr[prev+1] = arr[prev];
				prev --;
		}
		arr[prev+1] = current;//placing the current in its correct position
	}
}
void printarray(){
	for(int i=0;i<n;i++){
		cout<<arr[i]<<" ";
	}
}

int main(){
	int n=6;
	int arr[] = {11,1,5,4,3,2};
	
	insertionsort(arr, n);
	printarray(arr, n);
	return 0;
}