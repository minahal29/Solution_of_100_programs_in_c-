#include<iostream>
using namespace std;
int main()
{
	int n=1;
	int k=5;
	for(int i=1;i<=k;i++)
	{
		for(int j=1;j<=k;j++)
		{
			cout<<n<<" ";
			n +=2;
		}
		cout<<endl;
	}
    return 0;
}